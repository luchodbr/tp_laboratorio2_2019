﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Canasta<T> where T : Ivegetales
    {
        private List<T> plantas;

        public List<T> Plantas
        {
            get { return plantas; }
            set { plantas = value; }
        }

        private short capacidad;

        private Canasta()
        {
            this.plantas = new List<T>();
        }
        public Canasta(short capacidad) : this()
        {
            this.capacidad = capacidad;
        }

        public static Canasta<T> operator +(Canasta<T> c, ReinoVegetal r)
        {
            if (r is T)
            {
                if (c.plantas.Count < c.capacidad)
                {
                    T aux = (T)Convert.ChangeType(r, typeof(T));
                    c.plantas.Add(aux);

                    return c;
                }
                else
                {
                    // Lanzar excepción con el mensaje "Capacidad excedida."
                    throw new NoAgregaException("Capacidad excedida");
                }
            }
            else
            {
                // Lanzar excepción con el mensaje "El elemento es del tipo {0}. Se esperaba {1}."
                string s = String.Format("El elemento es del tipo {0}. Se esperaba {1}.", r.GetType().ToString(), typeof(T).ToString());
                throw new NoAgregaException(s);
            }
        }


        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Capacidad: " + this.capacidad);
            foreach (T reinoVegetal in this.plantas)
            {
                sb.AppendLine(reinoVegetal.MostrarDatos());
            }
            return sb.ToString();
        }
    }
}
