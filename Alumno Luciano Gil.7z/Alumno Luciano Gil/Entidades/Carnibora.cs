﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Carnibora : ReinoVegetal , Ivegetales
    {
        // Tipos del enumerado: Pinzas, Pelos, Caída, Mecánicas, Combinada
        private Captura tipo;

        public Captura Tipo
        {
            get { return tipo; }
        }

        private int tamanio;

        public int Tamanio
        {
            get { return tamanio; }
        }


        public Carnibora(float valor, Gusto gusto, Captura tipo) : base(valor,gusto)
        {
            // Completar
            this.tipo = tipo;
        }

        public Carnibora(float valor, Gusto gusto, Captura tipo, int tamanio) : this(valor,gusto,tipo)
        {
            // Completar
            this.tamanio = tamanio;
        }

        public enum Captura
        {
            Pinzas, Pelos, Caída, Mecánicas, Combinada
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine("el tipo es "+this.tipo.ToString());
            sb.AppendLine("el tamaño es "+this.tamanio.ToString());
            return sb.ToString();
        }
        public static implicit operator string(Carnibora c)
        {
            return c.ToString();
        }

        public string MostrarDatos()
        {
            return this.ToString();
        }
    }
}
