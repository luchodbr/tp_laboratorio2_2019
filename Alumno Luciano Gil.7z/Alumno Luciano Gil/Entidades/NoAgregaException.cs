﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class NoAgregaException : Exception
    {
        public NoAgregaException() : this("Ha ocurrido una excepcion del tipo NO AGREGA EXCEPTION")
        {

        }
        public NoAgregaException(string s) : base(s)
        {

        }
    }
}
