﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    [Serializable]
    public class Fruta : ReinoVegetal , Ivegetales
    {
        private ConsoleColor color;

        public ConsoleColor Color
        {
            get { return color; }
        }

        public Fruta() 
        {

        }
        public Fruta(float valor, Gusto gusto, ConsoleColor color) : base(valor,gusto)
        {
            // Completar
            this.color = color;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine("el color es "+this.color.ToString());
            return sb.ToString();
        }
        public static implicit operator string(Fruta f)
        {
            return f.ToString();
        }

        public string MostrarDatos()
        {
            return this.ToString();
        }
    }
}
