﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Verdura :ReinoVegetal, Ivegetales
    {
        // Tipos del enumerado Semilla, Raíz, Tubérculo, Bulbo, Tallo, Hoja, Inflorescencia, Rizoma

        private TipoVerdura tipo;

        public TipoVerdura Tipo
        {
            get { return tipo; }
        }


        public Verdura(float valor, Gusto gusto, TipoVerdura tipo) : base(valor,gusto)
        {
            // Completar
            this.tipo = tipo;
        }

        public enum TipoVerdura
        {
            Semilla, Raíz, Tubérculo, Bulbo, Tallo, Hoja, Inflorescencia, Rizoma
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine("el tipo es : "+this.tipo.ToString());
            return sb.ToString();
        }
        public static implicit operator string(Verdura v)
        {
            return v.ToString();
        }
        public string MostrarDatos()
        {
            return this.ToString();
        }
    }
}
