﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
namespace Entidades
{
    public static class GuardaElemento
    {
        public static string MostrarElemento(this Fruta fruta)
        {
            string fru = fruta.MostrarDatos();
            string s = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + "Datos.txt";
            try
            {
                using (StreamWriter open = new StreamWriter(s, true))
                {
                    open.WriteLine(fru);
                }

            }
            catch (Exception e)
            {
                throw e;
            }

            ///////////////////////
            try
            {
                s = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + "Datos.xml";
                using (XmlTextWriter writer = new XmlTextWriter(s, Encoding.UTF8))
                {
                    XmlSerializer serX = new XmlSerializer(typeof(Fruta));
                    serX.Serialize(writer, fruta);
                }

            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                s = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\" + "Datos.bin";
                using (FileStream fs = new FileStream(s, FileMode.Create))
                {

                    BinaryFormatter ser;
                    ser = new BinaryFormatter();
                    ser.Serialize(fs,fruta);
                }

            }
            catch (Exception e)
            {

                throw e;
            }

            return fru;
        }
    }
}
