﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    [Serializable]
    public abstract class ReinoVegetal
    {
        // Tipos del enumerado Dulce, Salado, Toxica
        public enum Gusto {Dulce, Salado, Toxica };

        public static Random calcularValor;
        private float valor;

        public float Valor
        {
            get { return valor; }
        }

        private Gusto gusto;

        public Gusto _Gusto
        {
            get { return gusto; }
        }


        public ReinoVegetal()
        {
            
        }
        static ReinoVegetal()
        {
            ReinoVegetal.calcularValor = new Random();
        }
        public ReinoVegetal(Gusto gusto)
        {
            this.valor = calcularValor.Next(1, 100);
        }

        public ReinoVegetal(float valor, Gusto gusto)
        {
            this.valor = valor;
            this.gusto = gusto;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("El valor es: "+this.valor.ToString());
            sb.AppendLine("El gusto es: " + this.gusto.ToString());
            return sb.ToString();
        }
        public static implicit operator string(ReinoVegetal r)
        {
            return r.ToString();
        }
        public static bool operator ==(ReinoVegetal r1, ReinoVegetal r2)
        {
            if (r1.GetType() == r2.GetType() && r1.gusto == r2.gusto)
                return true;
            else
                return false;
        }
        public static bool operator !=(ReinoVegetal r1, ReinoVegetal r2)
        {
            return !(r1 == r2);
        }
    }
}
