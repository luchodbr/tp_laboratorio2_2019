﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
namespace PruebaUnitaria
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException(typeof(NoAgregaException))]
        public void TestMethod1()
        {
            Canasta<Fruta> c = new Canasta<Fruta>(1);
            c.Plantas.Add(new Fruta());
            c.Plantas.Add(new Fruta());


        }
    }
}
