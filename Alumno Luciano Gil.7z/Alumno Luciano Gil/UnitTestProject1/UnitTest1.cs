﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]

        [ExpectedException(typeof(NoAgregaException))]
        public void TestMethod1()
        {
            Canasta<Fruta> c = new Canasta<Fruta>(1);
            c+=(new Fruta(1,ReinoVegetal.Gusto.Dulce,ConsoleColor.Black));
            c+=(new Fruta(2, ReinoVegetal.Gusto.Salado, ConsoleColor.Cyan));


        }
    }
}
